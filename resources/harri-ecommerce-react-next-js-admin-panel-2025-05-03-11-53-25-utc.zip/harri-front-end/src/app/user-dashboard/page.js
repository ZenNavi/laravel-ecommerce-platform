import UserDashboardMainArea from "@components/user-dashboard/user-dashboard-main-area";

export const metadata = {
  title: "User Dashboard - Harri Shop",
};

export default function UserDashboardPage() {
  return (
    <UserDashboardMainArea/>
  );
}
