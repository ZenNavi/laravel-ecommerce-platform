import CheckoutMainArea from "@components/checkout/checkout-main";

export const metadata = {
  title: "Checkout - Harri Shop",
};

const Checkout = () => {
  return (
    <CheckoutMainArea/>
  );
};

export default Checkout;
